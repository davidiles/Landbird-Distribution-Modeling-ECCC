# ============================================================
# 07_fit_models_and_predict.R   (merged: PC+ARU  and  PC+ARU+checklists)
#
# Purpose
#   Fit joint OBBA2/OBBA3 INLA/inlabru models for selected species and
#   generate prediction products on the full 1-km prediction grids.
#
#   This single script replaces the two near-identical scripts
#   (07_..._PC_ARU.R and 07_..._PC_ARU_CL.R). Choose which analysis to run
#   with the `survey_set` switch in the "CHOOSE WHICH MODEL TO RUN" block below.
#   Everything else in the script is shared by both modes.
#
# What differs between the two modes (and ONLY these things):
#   1. model_name           -> controls the output folder names.
#   2. Which survey types are kept:
#        "PC_ARU"     keeps point counts + ARUs only (checklists excluded).
#        "PC_ARU_CL"  keeps point counts + ARUs + checklists.
#   3. The model-fitting function:
#        "PC_ARU"     uses fit_PC_ARU()       (point counts + ARUs)
#        "PC_ARU_CL"  uses fit_PC_ARU_CL()    (adds checklist effort corrections)
#
# Count handling is the SAME in both modes: no counts are trimmed, and the
# negative-binomial likelihood is used when the data look over-dispersed (see
# the "Global configuration" block).
#
# Main outputs
#   - predictions_<model_name>/<species>_1km.rds
#   - summaries_<model_name>/model_summaries.rds
#   - data_used_<model_name>/<species>_1km.rds
#
# Note
#   data_used_<model_name>/ contains lightweight honeycomb data for every
#   species with detections in OBBA3. The is_modelable flag controls whether
#   full model fitting proceeds downstream; non-modelable species still keep
#   honeycomb data.
# ============================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(sf)
  library(ggplot2)
  library(INLA)
  library(inlabru)
  library(fmesher)
  library(here)
  library(mgcv)
})

source(here::here("R", "00_config_paths.R"))
source(file.path(paths$functions, "inla_model_utils.R"))

# ============================================================
# CHOOSE WHICH MODEL TO RUN  (this is normally the only line you edit)
# ============================================================
#   "PC_ARU"     = point counts + ARUs
#   "PC_ARU_CL"  = point counts + ARUs + checklists (adds effort corrections)

survey_set <- "PC_ARU"

# ------------------------------------------------------------
# Settings that differ between the two modes.
# Each entry is everything that changes when you switch modes; the rest of the
# script reads from the selected entry (`mode`) and never refers to the mode by
# name again.
# ------------------------------------------------------------
mode_settings <- list(
  
  PC_ARU = list(
    model_name   = "PC_ARU",
    fit_function = fit_PC_ARU,
    # Keep only point counts and ARUs; checklists are excluded.
    survey_types = c("Point_Count", "ARU")
  ),
  
  PC_ARU_CL = list(
    model_name   = "PC_ARU_CL",
    fit_function = fit_PC_ARU_CL,
    # Keep all survey types (point counts + ARUs + checklists).
    # NULL means "no survey-type filter".
    survey_types = NULL
  )
)

stopifnot(survey_set %in% names(mode_settings))
mode       <- mode_settings[[survey_set]]
model_name <- mode$model_name
fit_model  <- mode$fit_function

message("Mode: ", survey_set, "  ->  model_name = ", model_name)

# ============================================================
# 1. Global configuration shared by both modes
# ============================================================

rerun_models      <- FALSE
rerun_predictions <- FALSE

n_prediction_draws <- 500
prediction_seed    <- 123

min_detections <- 50
min_squares    <- 20

# Count handling (same for both modes):
#   - No counts are trimmed.
#   - Use the negative-binomial likelihood when the top 1% of nonzero counts
#     hold >= 10% of all individuals, OR more than `nb_switch_min_n` surveys
#     exceed `nb_switch_count`.
nb_switch_count <- 20
nb_switch_min_n <- 20

# Candidate fixed-effect covariates. Species-specific filtering below removes
# covariates that are absent from the data or have no variation after filtering.
base_covars <- c(
  "ForestNeedleleaf", "ForestBroadleaf", "ForestMixed", "Wetland", "Cropland",
  "Urban", "On_Road",
  "Grassland_BCR7_8", "Grassland_BCR12_13",
  "Shrubland_BCR13", "Shrubland_BCR7_8_12",
  "Lake_Lg", "Lake_Sm", "GreatLakes", "HudsonBayCoast",
  "River_Lg_BCR7", "River_Lg_BCR13_12_8",
  "River_Sm_BCR7", "River_Sm_BCR13_12_8"
)

# Priors passed to the fit function. (The PC_ARU_CL model also has effort priors
# with sensible defaults; pass them here too if you want to tune them.)
priors_list <- list(
  prior_range_abund = c(200, 0.1),      # 10% chance range is less than 200 km
  prior_sigma_abund = c(0.5, 0.1),      # 10% chance SD is larger than 0.5
  
  prior_range_change = c(200, 0.1),     # 10% chance range is less than 200 km
  prior_sigma_change = c(0.1, 0.1),     # 10% chance SD is larger than 0.1
  
  prior_HSS_range = c(2, 0.1),          # 10% chance range is less than 2 hours
  prior_HSS_sigma = c(1, 0.1),          # 10% chance SD is larger than 1
  
  prior_DOY_range_global = c(3, 0.1),   # 10% chance range is less than 3 days
  prior_DOY_sigma_global = c(1, 0.1),   # 10% chance SD is larger than 1
  
  kappa_pcprec_diff = c(log(2), 0.1)    # 10% chance square iid SD is larger than log(2)
)

# INLA approximation settings used inside the fit function.
int_strategy <- "ccd"
strategy     <- "laplace"

# ============================================================
# 2. Input/output locations
# ============================================================

in_file <- file.path(paths$data_clean, "birds", "data_ready_for_analysis.rds")

if (!file.exists(in_file)) {
  stop(
    "Cannot find input at: ", in_file,
    "\nHave you run 06_filter_and_finalize_surveys.R?"
  )
}

out_dir       <- paths$model_output
pred_dir      <- file.path(out_dir, paste0("predictions_", model_name))
summary_dir   <- file.path(out_dir, paste0("summaries_", model_name))
data_used_dir <- file.path(out_dir, paste0("data_used_", model_name))

purrr::walk(
  c(out_dir, pred_dir, summary_dir, data_used_dir),
  dir.create, recursive = TRUE, showWarnings = FALSE
)

model_summaries_path <- file.path(summary_dir, "model_summaries.rds")
model_summaries      <- load_or_empty_list(model_summaries_path)

# ============================================================
# 3. Load finalized data
# ============================================================

dat <- readRDS(in_file)

all_surveys         <- dat$all_surveys
counts              <- dat$counts
grid_OBBA2          <- dat$grid_OBBA2
grid_OBBA3          <- dat$grid_OBBA3
study_boundary      <- dat$study_boundary %>% sf::st_as_sf()
species_to_model    <- dat$species_to_model
safe_dates_breeding <- dat$safe_dates_breeding

# ============================================================
# 4. Select species
# ============================================================
# Two sets are used below:
#   - species_all : EVERY species (honeycomb survey data is saved for all of
#                   these, whether or not a model is fit).
#   - model_ids   : the subset that has enough data to fit a model. Only these
#                   species are fitted and predicted.

species_all <- species_to_model %>%
  arrange(detections_safe_OBBA3) %>%
  subset(detections_safe_OBBA3 > 0)

species_run <- species_to_model %>%
  filter(
    (detections_safe_OBBA2 >= min_detections |
       detections_safe_OBBA3 >= min_detections) &
      (n_squares_safe_OBBA2 >= min_squares |
         n_squares_safe_OBBA3 >= min_squares)
  ) %>%
  filter(
    !is.na(detections_safe_OBBA2),
    !is.na(detections_safe_OBBA3),
    !is.na(n_squares_safe_OBBA2),
    !is.na(n_squares_safe_OBBA3)
  ) %>%
  mutate(
    delta_dets_safe    = log(detections_safe_OBBA3 / detections_safe_OBBA2),
    delta_squares_safe = log(n_squares_safe_OBBA3 / n_squares_safe_OBBA2)
  ) %>%
  arrange(abs(delta_squares_safe))

model_ids <- as.character(species_run$species_id)

message("Species total (honeycomb data saved for all): ", nrow(species_all))
message("Species to model: ", length(model_ids))

# ============================================================
# 5. Main species loop
# ============================================================

for (i in  sort(seq_len(nrow(species_all)), decreasing = F)){
  
  # ----------------------------------------------------------
  # 5.1 Species identifiers and output paths
  # ----------------------------------------------------------
  
  sp_name <- species_all$english_name[i]
  sp_code <- as.character(species_all$species_id[i])
  sp_file <- sp_filename(sp_name)
  
  message(
    "\n====================\n",
    i, "/", nrow(species_all), ": ", sp_name,
    " (species_id = ", sp_code, ")\n",
    "===================="
  )
  
  pred_path <- file.path(pred_dir, paste0(sp_file, "_1km.rds"))
  dat_path  <- file.path(data_used_dir, paste0(sp_file, "_1km.rds"))
  
  if (!(sp_code %in% names(counts))) {
    message("Skipping; species_id not found in counts columns: ", sp_code)
    next
  }
  
  # Does this species have enough data to fit a model? Honeycomb survey data is
  # saved either way; only modelable species are fitted and predicted.
  is_modelable <- sp_code %in% model_ids
  
  sp_dat <- all_surveys %>%
    mutate(count = counts[[sp_code]])
  
  # Restrict to the survey types used by this mode. PC_ARU keeps only point
  # counts and ARUs (checklists excluded); PC_ARU_CL keeps everything
  # (survey_types = NULL).
  if (!is.null(mode$survey_types)) {
    sp_dat <- sp_dat %>% filter(Survey_Type %in% mode$survey_types)
  }
  
  # ----------------------------------------------------------
  # 5.2 Apply species-specific safe-date filtering
  # ----------------------------------------------------------
  # Keep only surveys within the species-specific safe-date window for each
  # biological region. If a region has no species-specific safe dates, fall back
  # to the shared window across available regions.
  #
  # If the species has NO usable safe-date window at all, fall back to using ALL
  # surveys (after the survey-type filter) for the honeycomb, print a message,
  # and do not fit a model for it.
  
  sp_safe_dates <- safe_dates_breeding %>% filter(sp_english == sp_name)
  fell_back_all <- FALSE
  pred_doy      <- NA_real_
  
  if (nrow(sp_safe_dates) == 0) {
    message("No safe-date records for ", sp_name, "; using all surveys for honeycomb.")
    sp_safe_dates <- NULL
    fell_back_all <- TRUE
  } else {
    fallback_start <- max(sp_safe_dates$start_doy, na.rm = TRUE)
    fallback_end   <- min(sp_safe_dates$end_doy, na.rm = TRUE)
    
    if (!is.finite(fallback_start) ||
        !is.finite(fallback_end) ||
        fallback_start > fallback_end) {
      message("No valid safe-date window for ", sp_name,
              "; using all surveys for honeycomb.")
      fell_back_all <- TRUE
    } else {
      all_regions     <- sp_dat %>% distinct(Biol_Region)
      safe_regions    <- sp_safe_dates %>% distinct(Biol_Region)
      missing_regions <- all_regions %>% anti_join(safe_regions, by = "Biol_Region")
      
      if (nrow(missing_regions) > 0) {
        sp_safe_dates <- bind_rows(
          sp_safe_dates,
          missing_regions %>%
            mutate(
              sp_english = sp_name,
              start_doy  = fallback_start,
              end_doy    = fallback_end,
              midpoint   = floor((fallback_start + fallback_end) / 2)
            ) %>%
            select(sp_english, Biol_Region, start_doy, end_doy, midpoint)
        )
      }
      
      # Prediction reference date: midpoint of the shared safe-date window.
      pred_doy <- floor((fallback_start + fallback_end) / 2)
      
      sp_dat <- sp_dat %>%
        left_join(sp_safe_dates, by = "Biol_Region") %>%
        filter(
          !is.na(start_doy),
          !is.na(end_doy),
          DayOfYear >= start_doy,
          DayOfYear <= end_doy
        ) %>%
        mutate(
          days_midpoint     = DayOfYear - pred_doy,
          duration_rescaled = Survey_Duration_Minutes - 5
        )
    }
  }
  
  # A species without a usable safe-date window cannot be fit (no prediction
  # reference date / day-of-year covariate), so it is honeycomb-only.
  if (fell_back_all && is_modelable) {
    message("  (", sp_name, " has no safe-date window; honeycomb only, not modelled.)")
    is_modelable <- FALSE
  }
  
  if (nrow(sp_dat) == 0) {
    message("Skipping ", sp_name, "; no surveys remain after filtering.")
    next
  }
  
  # ----------------------------------------------------------
  # 5.2b Save lightweight honeycomb survey data (EVERY species)
  # ----------------------------------------------------------
  # Only survey_id + count are stored. Geometry and all other survey attributes
  # live once in all_surveys and are rejoined by survey_id downstream (script
  # 08), so survey geometry is never duplicated across species.
  
  honeycomb_counts <- sp_dat %>%
    sf::st_drop_geometry() %>%
    select(survey_id, count)
  
  # ----------------------------------------------------------
  # 5.2c Choose likelihood family
  # ----------------------------------------------------------
  # No counts are trimmed. The negative-binomial likelihood is used when the
  # data look over-dispersed, per the shared thresholds set in the global
  # configuration (nb_switch_count / nb_switch_min_n).
  
  n_det <- sum(sp_dat$count > 0)
  y_pos <- sp_dat$count[sp_dat$count > 0]
  
  if (length(y_pos) == 0) {
    message("Skipping ", sp_name, "; no positive counts remain after filtering.")
    next
  }
  
  n_top <- max(1, ceiling(0.01 * n_det))
  
  prop_total_top1pct_nonzero <- sum(
    sort(y_pos, decreasing = TRUE)[seq_len(n_top)]
  ) / sum(y_pos)
  
  error_family <- "poisson"
  if (prop_total_top1pct_nonzero >= 0.10 ||
      sum(y_pos > nb_switch_count) > nb_switch_min_n) {
    error_family <- "nbinomial"
  }
  
  # Save data summary
  saveRDS(
    list(
      sp_english       = sp_name,
      sp_code          = sp_code,
      is_modelable     = is_modelable,
      sp_safe_dates    = sp_safe_dates,     # NULL if none were found
      pred_doy         = pred_doy,          # NA if all surveys were used
      used_all_surveys = fell_back_all,
      survey_counts    = honeycomb_counts,   # survey_id + count, no geometry
      error_family     = error_family
    ),
    dat_path
  )

  # ----------------------------------------------------------
  # 5.3 Decide whether to fit a model
  # ----------------------------------------------------------
  # Honeycomb data is already saved above. Only proceed to model fitting and
  # prediction for species with enough data.
  
  if (!is_modelable) {
    message("Honeycomb data saved for ", sp_name, "; not enough data to fit a model.")
    next
  }
  
  if (file.exists(pred_path) && !rerun_predictions) {
    message("Predictions already exist for ", sp_name, "; skipping model fit.")
    next
  }
  
  
  # ----------------------------------------------------------
  # 5.4 Estimate reference Hours Since Sunrise
  # ----------------------------------------------------------
  # Fit a simple GAM to estimate the survey time with the highest expected
  # count. This value is used as the standardized HSS value for prediction.
  
  hss_dat <- sp_dat %>%
    filter(
      Survey_Type %in% c("Point_Count", "ARU"),
      is.finite(Hours_Since_Sunrise)
    )
  
  if (nrow(hss_dat) < 50 || dplyr::n_distinct(hss_dat$Hours_Since_Sunrise) < 5) {
    optimal_HSS <- median(sp_dat$Hours_Since_Sunrise, na.rm = TRUE)
    message("Using median HSS for ", sp_name, ": ", round(optimal_HSS, 2))
  } else {
    hss_gam <- mgcv::gam(
      count ~ s(Hours_Since_Sunrise),
      data   = hss_dat,
      family = "poisson"
    )
    
    hss_min <- quantile(hss_dat$Hours_Since_Sunrise, 0.05, na.rm = TRUE)
    hss_max <- quantile(hss_dat$Hours_Since_Sunrise, 0.95, na.rm = TRUE)
    
    hss_pred <- data.frame(
      Hours_Since_Sunrise = seq(hss_min, hss_max, length.out = 100)
    )
    hss_pred$pred <- predict(hss_gam, newdata = hss_pred, type = "response")
    
    optimal_HSS <- hss_pred$Hours_Since_Sunrise[which.max(hss_pred$pred)]
    
    plot(
      pred ~ Hours_Since_Sunrise,
      data = hss_pred,
      type = "l",
      main = paste0(
        sp_name,
        " - effect of Hours Since Sunrise\n\nOptimal survey timing = ",
        round(optimal_HSS, 2), " hours since sunrise"
      ),
      lwd = 2
    )
    abline(v = optimal_HSS, lty = 2, col = "blue")
  }
  
  # ----------------------------------------------------------
  # 5.6 Build species-specific covariate table
  # ----------------------------------------------------------
  # Retain only candidate covariates that:
  #   1. exist in this species dataset; and
  #   2. have more than one unique finite value after filtering.
  
  covars_present <- intersect(base_covars, names(sp_dat))
  
  if (length(covars_present) > 0) {
    cov_n_unique <- sp_dat %>%
      sf::st_drop_geometry() %>%
      select(all_of(covars_present)) %>%
      summarise(
        across(
          everything(),
          ~ dplyr::n_distinct(.x[is.finite(.x)], na.rm = TRUE)
        )
      ) %>%
      tidyr::pivot_longer(
        cols      = everything(),
        names_to  = "covariate",
        values_to = "n_unique"
      )
    
    covars_present <- cov_n_unique %>%
      filter(n_unique > 1) %>%
      pull(covariate)
  }
  
  cov_df_sp <- make_cov_df(
    covars_present,
    mean      = 0,
    sd_linear = 0.5
  )
  
  # ----------------------------------------------------------
  # 5.7 Fit model
  # ----------------------------------------------------------
  # `fit_model` was selected by `survey_set` above. Both fit functions take the
  # same arguments here; the PC_ARU_CL model adds checklist effort terms
  # internally.
  
  start_model <- Sys.time()
  
  mod <- try(
    fit_model(
      sp_dat         = sp_dat,
      study_boundary = study_boundary,
      covariates     = cov_df_sp,
      
      prior_range_abund = priors_list$prior_range_abund,
      prior_sigma_abund = priors_list$prior_sigma_abund,
      
      prior_range_change = priors_list$prior_range_change,
      prior_sigma_change = priors_list$prior_sigma_change,
      
      prior_HSS_range = priors_list$prior_HSS_range,
      prior_HSS_sigma = priors_list$prior_HSS_sigma,
      
      prior_DOY_range_global = priors_list$prior_DOY_range_global,
      prior_DOY_sigma_global = priors_list$prior_DOY_sigma_global,
      
      kappa_pcprec_diff = priors_list$kappa_pcprec_diff,
      
      int_strategy = int_strategy,
      strategy     = strategy,
      family       = error_family
    ),
    silent = TRUE
  )
  
  if (inherits(mod, "try-error") || is.null(mod)) {
    message("Model failed for ", sp_name, "; skipping this species.")
    print(mod)
    next
  }
  
  end_model   <- Sys.time()
  fit_minutes <- round(as.numeric(end_model - start_model, units = "mins"), 1)
  
  model_summaries[[sp_name]] <- list(
    sp_name          = sp_name,
    sp_code          = sp_code,
    error_family     = error_family,
    priors           = priors_list,
    int_strategy     = int_strategy,
    strategy         = strategy,
    n_surveys        = nrow(sp_dat),
    n_detections     = n_det,
    n_covariates     = nrow(cov_df_sp),
    covariates       = cov_df_sp,
    pred_doy         = pred_doy,
    optimal_HSS      = optimal_HSS,
    fit_minutes      = fit_minutes,
    summary_fixed    = mod$summary.fixed,
    summary_hyperpar = mod$summary.hyperpar
  )
  
  save_atomic(model_summaries, model_summaries_path)
  
  print(summary(mod))
  
  message(
    "\n====================\n",
    i, "/", nrow(species_all), ": ", sp_name,
    " (species_id = ", sp_code, "); ", fit_minutes, " min to fit model\n",
    "===================="
  )
  
  # ----------------------------------------------------------
  # 5.8 Generate full-grid predictions
  # ----------------------------------------------------------
  # Predictions are standardized to:
  #   - optimal_HSS for Hours_Since_Sunrise
  #   - days_midpoint = 0, i.e. the shared safe-date midpoint
  
  start_prediction <- Sys.time()
  message("Generating predictions for full 1-km grid")
  
  pred_formula <- make_pred_formula_multiatlas(cov_df_sp)
  
  pred_grid <- make_pred_grid(grid_OBBA2, grid_OBBA3) %>%
    mutate(
      Hours_Since_Sunrise = optimal_HSS,
      days_midpoint       = 0
    )
  
  preds <- predict_all_pixels(
    mod          = mod,
    pred_grid    = pred_grid,
    pred_formula = pred_formula,
    n.samples    = n_prediction_draws,
    seed         = prediction_seed
  )
  
  gc()
  
  # ----------------------------------------------------------
  # 5.9 Apply terrestrial open-water correction
  # ----------------------------------------------------------
  # Scales predicted abundance by the non-open-water fraction of each pixel.
  # Assumes the model estimates terrestrial abundance/density.
  
  preds$mu2_Corrected_for_Water <- preds$mu2 * (1 - grid_OBBA2$open_water)
  preds$mu3_Corrected_for_Water <- preds$mu3 * (1 - grid_OBBA3$open_water)
  
  # ----------------------------------------------------------
  # 5.10 Summarize pixel predictions and hex draws
  # ----------------------------------------------------------
  
  pred_summary <- summarize_predictions(preds$mu2, preds$mu3)
  
  pred_summary_Corrected_for_Water <- summarize_predictions(
    preds$mu2_Corrected_for_Water,
    preds$mu3_Corrected_for_Water
  )
  
  g2 <- pred_grid %>% filter(Atlas == "OBBA2")
  g3 <- pred_grid %>% filter(Atlas == "OBBA3")
  
  preds_OBBA2_summary <- bind_cols(
    g2 %>% st_drop_geometry() %>% select(pixel_id, hex_id),
    pred_summary$OBBA2
  )
  preds_OBBA3_summary <- bind_cols(
    g3 %>% st_drop_geometry() %>% select(pixel_id, hex_id),
    pred_summary$OBBA3
  )
  preds_abs_change_summary <- bind_cols(
    g2 %>% st_drop_geometry() %>% select(pixel_id, hex_id),
    pred_summary$abs_change
  )
  
  hex_draws <- make_hex_draws(g2 = g2, mu2 = preds$mu2, mu3 = preds$mu3)
  
  preds_OBBA2_summary_Corrected_for_Water <- bind_cols(
    g2 %>% st_drop_geometry() %>% select(pixel_id, hex_id),
    pred_summary_Corrected_for_Water$OBBA2
  )
  preds_OBBA3_summary_Corrected_for_Water <- bind_cols(
    g3 %>% st_drop_geometry() %>% select(pixel_id, hex_id),
    pred_summary_Corrected_for_Water$OBBA3
  )
  preds_abs_change_summary_Corrected_for_Water <- bind_cols(
    g2 %>% st_drop_geometry() %>% select(pixel_id, hex_id),
    pred_summary_Corrected_for_Water$abs_change
  )
  
  hex_draws_Corrected_for_Water <- make_hex_draws(
    g2  = g2,
    mu2 = preds$mu2_Corrected_for_Water,
    mu3 = preds$mu3_Corrected_for_Water
  )
  
  end_prediction <- Sys.time()
  pred_minutes   <- round(as.numeric(end_prediction - start_prediction, units = "mins"), 1)
  
  # ----------------------------------------------------------
  # 5.11 Summarize observed survey coverage by atlas square
  # ----------------------------------------------------------
  
  sp_square_summary <- sp_dat %>%
    as.data.frame() %>%
    group_by(Atlas, square_id) %>%
    summarise(
      n_surveys    = n(),
      total_count  = sum(count),
      n_detections = sum(count > 0),
      BCR          = names(which.max(table(BCR))),
      .groups      = "drop"
    )
  
  # ----------------------------------------------------------
  # 5.12 Save prediction products
  # ----------------------------------------------------------
  
  save_atomic(
    list(
      sp_name           = sp_name,
      sp_code           = sp_code,
      sp_safe_dates     = sp_safe_dates,
      sp_square_summary = sp_square_summary,
      
      error_family = error_family,
      priors       = priors_list,
      int_strategy = int_strategy,
      strategy     = strategy,
      
      fit_minutes  = fit_minutes,
      pred_minutes = pred_minutes,
      
      summary_fixed    = mod$summary.fixed,
      summary_hyperpar = mod$summary.hyperpar,
      
      pred_doy           = pred_doy,
      optimal_HSS        = optimal_HSS,
      prediction_seed    = prediction_seed,
      n_prediction_draws = n_prediction_draws,
      
      # Predictions for terrestrial habitats
      OBBA2      = preds_OBBA2_summary,
      OBBA3      = preds_OBBA3_summary,
      abs_change = preds_abs_change_summary,
      hex_draws  = hex_draws,
      
      # Predictions that correct for open-water proportion in each pixel
      OBBA2_Corrected_for_Water      = preds_OBBA2_summary_Corrected_for_Water,
      OBBA3_Corrected_for_Water      = preds_OBBA3_summary_Corrected_for_Water,
      abs_change_Corrected_for_Water = preds_abs_change_summary_Corrected_for_Water,
      hex_draws_Corrected_for_Water  = hex_draws_Corrected_for_Water
    ),
    pred_path
  )
  
  message(
    "\n====================\n",
    i, "/", nrow(species_all), ": ", sp_name,
    " (species_id = ", sp_code, "); ", pred_minutes,
    " min to generate predictions\n",
    "===================="
  )
  
  rm(preds, pred_grid, g2, g3, hex_draws, hex_draws_Corrected_for_Water)
  gc(verbose = FALSE)
}

message("\n07_fit_models_and_predict.R complete  (mode: ", survey_set, ").")
