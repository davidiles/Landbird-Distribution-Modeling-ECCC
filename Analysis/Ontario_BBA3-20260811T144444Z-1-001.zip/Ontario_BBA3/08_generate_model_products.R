# ============================================================
# 08_generate_model_products.R   (restructured: updated3)
#
# Purpose
#   Convert fitted model prediction RDS files into map-ready rasters and
#   multi-page species assessment PDFs.
#
# Main outputs (unchanged from updated2)
#   - model_output/rasters_<model_name>/<species>_a2.tif
#   - model_output/rasters_<model_name>/<species>_a3.tif
#   - model_output/rasters_<model_name>/<species>_chg.tif
#   - model_output/figures_<model_name>/<species>.pdf  (10 pages, same order)
#
# What changed relative to updated2 (structure + speed only; outputs preserved)
#   1. All tunable constants collected in a single CONFIG block.
#   2. Constant, species-independent geometry (region polygons, the four
#      assessment hex grids, clipped atlas regions, colour palettes) is built
#      ONCE before the species loop instead of every iteration.
#   3. The four copy-pasted regional assessment blocks (Provincial, Southern,
#      Boreal, Hudson Bay) are unified into build_period_assessments().
#   4. The ten copy-pasted PNG-writing blocks are unified into save_page().
#   5. The unused Relabund_Map_Atlas2/3 plots (not referenced by any PDF page
#      in updated2) are commented out -- see note in the loop.
#
# Notes (carried over from updated2)
#   - Relative abundance means are water-corrected; CI widths are still taken
#     from the uncorrected summaries, matching the original script.
#   - CRS choices are inherited from the saved analysis-ready data; objects are
#     aligned to the prediction-grid CRS only.
# ============================================================

rm(list = ls())

suppressPackageStartupMessages({
  library(sf)
  library(dplyr)
  library(ggplot2)
  library(terra)
  library(patchwork)
  library(magick)
  library(viridis)
})

source(here::here("R", "00_config_paths.R"))
source(file.path(paths$functions, "model_product_utils.R"))

# ============================================================
# CONFIG
# ============================================================

model_name <- "PC_ARU"

cfg <- list(
  # Rasterization
  plot_res = 1001,            # raster resolution in map units (m in EPSG:3978)

  # Assessment hex grids / scaling
  n_hexagons    = 2000,
  rast_max_q    = 0.99,
  count_max_q   = 0.99,
  max_surveys_q = 0.80,

  # Change summaries
  ci_level   = 0.90,
  min_sq_det = 10,            # hide regional change unless detected in >= this many squares

  # Relative-abundance / PObs absence floor (1 expected bird per 500 counts)
  relabund_absent_limit = 1 / 500,

  # PDF page rendering
  page_width  = 20,
  page_height = 10,
  page_res    = 300
)

# Atlas biological regions used for the sub-region panels.
# Region numbers come from atlas_regions$Biol_Regio.
region_defs <- list(
  province = list(biol_regio = NULL,    suffix = ""),                 # whole study area
  southern = list(biol_regio = c(1, 2, 3), suffix = "Southern Ontario"),
  boreal   = list(biol_regio = c(4),       suffix = "Boreal Ontario"),
  hb       = list(biol_regio = c(5),       suffix = "Hudson Bay")
)

# ------------------------------------------------------------
# Paths and directories
# ------------------------------------------------------------

in_data  <- file.path(paths$data_clean, "birds", "data_ready_for_analysis.rds")
pred_dir <- file.path(paths$model_output, paste0("predictions_", model_name))
rast_dir <- file.path(paths$model_output, paste0("rasters_", model_name))
fig_dir  <- file.path(paths$model_output, paste0("figures_", model_name))
png_dir  <- file.path(fig_dir, "PNGs")
data_used_dir <- file.path(paths$model_output, paste0("data_used_", model_name))
out_dir  <- paths$model_output

model_summaries_path <- file.path(
  out_dir, paste0("summaries_", model_name), "model_summaries.rds"
)
paired_analysis_path <- file.path(out_dir, "paired_summaries", "paired_summaries.rds")

for (dir_i in c(rast_dir, fig_dir, png_dir)) {
  dir.create(dir_i, recursive = TRUE, showWarnings = FALSE)
}

stopifnot(file.exists(in_data))
stopifnot(file.exists(model_summaries_path))

# ============================================================
# Load analysis-ready data and model summaries
# ============================================================

dat             <- readRDS(in_data)
model_summaries <- readRDS(model_summaries_path)

grid2          <- dat$grid_OBBA2 %>% na.omit()
grid3          <- dat$grid_OBBA3 %>% na.omit()
study_boundary <- dat$study_boundary %>% sf::st_as_sf()
hex_grid       <- dat$hex_grid_25km

# Align all map layers to the Atlas 2 prediction-grid CRS.
crs_use        <- sf::st_crs(grid2)
study_boundary <- sf::st_transform(study_boundary, crs_use)
grid2          <- sf::st_transform(grid2, crs_use)
grid3          <- sf::st_transform(grid3, crs_use)

# Shared survey table. Per-species data_used files store only survey_id + count;
# geometry and all survey attributes live here once and are rejoined by
# survey_id (see load_species_surveys()). all_surveys already carries a stable
# survey_id key.
all_surveys <- dat$all_surveys %>% sf::st_transform(crs_use)

# ------------------------------------------------------------
# Water polygons used as map overlays (load or build once)
# ------------------------------------------------------------

in_water <- file.path(paths$data_clean, "spatial", "water_to_plot.rds")

if (file.exists(in_water)) {
  water_to_plot <- readRDS(in_water)
} else {
  in_water_raw <- file.path(
    paths$data, "Spatial",
    "Ontario_Hydro_Network_(OHN)_-_Waterbody",
    "Ontario_Hydro_Network_(OHN)_-_Waterbody.shp"
  )

  water_to_plot <- sf::st_read(in_water_raw, quiet = TRUE) %>%
    sf::st_make_valid() %>%
    sf::st_transform(crs_use) %>%
    dplyr::mutate(area_m2 = as.numeric(sf::st_area(geometry))) %>%
    dplyr::filter(VERIFICATI == "Verified", area_m2 >= (5000 * 5000)) %>%
    sf::st_intersection(study_boundary) |>
    sf::st_collection_extract("POLYGON")

  saveRDS(water_to_plot, in_water)
}

# ------------------------------------------------------------
# Atlas regions (used to summarize change and as panel boundaries)
# ------------------------------------------------------------

atlas_regions <- sf::st_read(
  file.path(paths$data, "Spatial", "Ontario_Atlas_biol_regions", "Atlas_biol_regions.shp")
) %>%
  sf::st_transform(sf::st_crs(study_boundary)) %>%
  dplyr::arrange(Biol_Regio)

# Clipped copy reused by the repeated-survey locations map (built once, not per species).
atlas_regions_clipped <- atlas_regions %>% sf::st_intersection(study_boundary)

# ------------------------------------------------------------
# Paired-survey change estimates
# ------------------------------------------------------------

if (file.exists(paired_analysis_path)) {
  paired_summaries <- readRDS(paired_analysis_path)
} else {
  message("Paired summaries not found at: ", paired_analysis_path,
          "; species without paired results will receive honeycomb-only PDFs.")
  paired_summaries <- list()
}

# ============================================================
# Local helper functions
# ============================================================

# Render a single ggplot/patchwork page to a PNG (replaces the 10 copy-pasted
# agg_png/print/dev.off blocks).
save_page <- function(plot, path,
                      width  = cfg$page_width,
                      height = cfg$page_height,
                      res    = cfg$page_res) {
  ragg::agg_png(
    filename = path, width = width, height = height,
    units = "in", res = res, background = "white"
  )
  on.exit(grDevices::dev.off(), add = TRUE)
  print(plot)
  invisible(path)
}

# Build the Atlas 2 + Atlas 3 assessment panels for one region.
#
# Unifies the previously copy-pasted Provincial / Southern / Boreal / HB blocks.
# Rasters are pre-cropped/masked to the region and survey data are pre-filtered
# so that the shared display limits are computed on exactly the pixels and
# points each panel will show (matching updated2's sub-region behaviour). For
# the province the region is the full study boundary, so cropping is a no-op on
# values.
#
# Returns: list(A2 = <assess_region output>, A3 = <...>, scale_limits = <...>)
build_period_assessments <- function(region_geom,
                                     region_hex,
                                     r2, r3,
                                     A2_dat, A3_dat,
                                     atlas_regions,
                                     sp_english,
                                     title_suffix = "",
                                     colpal,
                                     rast_max_q    = cfg$rast_max_q,
                                     count_max_q   = cfg$count_max_q,
                                     max_surveys_q = cfg$max_surveys_q) {

  region_vect <- terra::vect(sf::st_transform(region_geom, terra::crs(r2)))

  r2_reg <- r2 |> terra::crop(region_vect) |> terra::mask(region_vect)
  r3_reg <- r3 |> terra::crop(region_vect) |> terra::mask(region_vect)

  # st_filter requires matching CRS. The precomputed region geometry is in the
  # study_boundary / prediction-grid CRS, but the per-species survey data may be
  # stored in a different CRS, so align the region to each data layer's CRS.
  A2_reg <- sf::st_filter(
    A2_dat, sf::st_transform(region_geom, sf::st_crs(A2_dat)),
    .predicate = sf::st_intersects
  )
  A3_reg <- sf::st_filter(
    A3_dat, sf::st_transform(region_geom, sf::st_crs(A3_dat)),
    .predicate = sf::st_intersects
  )

  # Hex summaries first so display limits reflect both atlas periods together.
  A2_hex <- summarize_hex(dat = A2_reg, hex_grid = region_hex,
                          rast = r2_reg, rast_max_q = rast_max_q)
  A3_hex <- summarize_hex(dat = A3_reg, hex_grid = region_hex,
                          rast = r3_reg, rast_max_q = rast_max_q)

  lims <- compute_assessment_scale_limits(
    hex_summaries = list(A2_hex, A3_hex),
    rasts         = list(r2_reg, r3_reg),
    rast_max_q    = rast_max_q,
    count_max_q   = count_max_q,
    max_surveys_q = max_surveys_q
  )

  title_for <- function(period) {
    if (nzchar(title_suffix)) {
      paste0(sp_english, " - ", period, " - ", title_suffix)
    } else {
      paste0(sp_english, " - ", period)
    }
  }

  assess_one <- function(period, dat, rast) {
    assess_region(
      region               = region_geom,
      region_boundaries    = atlas_regions,
      sp_dat               = dat,
      rast                 = rast,
      hex_grid             = region_hex,
      water                = NULL,
      rast_max             = lims$rast_max,
      max_count_per_effort = lims$max_count_per_effort,
      max_surveys          = lims$max_surveys,
      transform            = "identity",
      title                = title_for(period),
      model_source         = NULL,
      data_source          = NULL,
      color_palette        = colpal
    )
  }

  list(
    A2           = assess_one("Atlas 2", A2_reg, r2_reg),
    A3           = assess_one("Atlas 3", A3_reg, r3_reg),
    scale_limits = lims
  )
}

# Reconstruct a species' survey sf from its lightweight data_used record.
# The data_used file stores only survey_id + count; everything else (geometry,
# Survey_Type, Atlas, Biol_Region, square_id, ...) is rejoined from all_surveys.
load_species_surveys <- function(dat_used, all_surveys) {
  all_surveys %>%
    dplyr::inner_join(dat_used$survey_counts, by = "survey_id") %>%
    dplyr::mutate(count_per_effort = count)
}

# Shared per-panel margin used when composing pages (matches assess_region).
margin_theme <- ggplot2::theme(plot.margin = ggplot2::margin(5, 10, 5, 10))

# Build the Atlas 2 + Atlas 3 *honeycomb-only* panels for one region.
#
# Used for species without a fitted model: there is no prediction raster, so the
# observed survey hex summary is rendered on its own (effort + observed mean
# count) via plot_honeycomb(). Atlas 2 and Atlas 3 share effort/count scaling so
# the two periods are directly comparable.
#
# Returns: list(A2 = <ggplot>, A3 = <ggplot>)
build_period_honeycombs <- function(region_geom,
                                    region_hex,
                                    region_bounds,
                                    A2_dat, A3_dat,
                                    sp_english,
                                    title_suffix  = "",
                                    max_surveys_q = cfg$max_surveys_q,
                                    count_max_q   = cfg$count_max_q) {

  A2_reg <- sf::st_filter(
    A2_dat, sf::st_transform(region_geom, sf::st_crs(A2_dat)),
    .predicate = sf::st_intersects
  )
  A3_reg <- sf::st_filter(
    A3_dat, sf::st_transform(region_geom, sf::st_crs(A3_dat)),
    .predicate = sf::st_intersects
  )

  # Survey-only hex summaries (no raster involved).
  A2_hex <- summarize_surveys_by_hex(dat = A2_reg, hex_grid = region_hex)
  A3_hex <- summarize_surveys_by_hex(dat = A3_reg, hex_grid = region_hex)

  # Shared scaling across both atlas periods. compute_assessment_scale_limits()
  # cannot be used here (it requires a pred_mean column when no raster is given),
  # so the two honeycomb limits are resolved directly with the same helper and
  # quantiles that plot_honeycomb / assess_region use.
  shared_max_surveys <- ceiling(resolve_positive_max(
    x = c(A2_hex$n_surveys, A3_hex$n_surveys),
    max_q = max_surveys_q, default = 1, argument_name = "max_surveys"
  ))
  shared_max_count <- resolve_positive_max(
    x = c(A2_hex$mean_count_per_effort, A3_hex$mean_count_per_effort),
    max_q = count_max_q, default = 1, argument_name = "max_count_per_effort"
  )

  honey_one <- function(hex_obs, period) {
    plot_honeycomb(
      hex_summary            = hex_obs,
      study_area             = region_geom,
      region_boundaries      = region_bounds,
      water                  = NULL,
      max_surveys            = shared_max_surveys,
      max_surveys_q          = max_surveys_q,
      max_count_per_effort   = shared_max_count,
      max_count_per_effort_q = count_max_q
    ) +
      # Replace plot_honeycomb's generic title with the atlas period; its
      # descriptive subtitle (hex fill / circle size) is retained.
      ggplot2::labs(title = period)
  }

  list(
    A2 = honey_one(A2_hex, "Atlas 2"),
    A3 = honey_one(A3_hex, "Atlas 3")
  )
}

# ============================================================
# Precompute species-independent objects (built ONCE)
# ============================================================

# Relative-abundance colour palette (deuteranomaly-friendly green ramp).
colpal_relabund <- grDevices::colorRampPalette(c(
  "#FBF7E2", "#FCF8D0", "#EEF7C2",
  "#CEF2B0",
  "#94E5A0", "#51C987", "#18A065", "#008C59",
  "#007F53", "#006344"
))(100)

# Probability-of-observation palette.
colpal_pobs <- viridis::mako(100, direction = -1)

# Region geometries + their assessment hex grids. These depend only on the
# study area and n_hexagons, so they are constant across all species.
make_region_geom <- function(biol_regio) {
  if (is.null(biol_regio)) {
    return(study_boundary)
  }
  subset(atlas_regions, Biol_Regio %in% biol_regio) %>%
    sf::st_union() %>%
    sf::st_intersection(study_boundary) %>%
    sf::st_transform(sf::st_crs(study_boundary)) %>%
    sf::st_as_sf()
}

region_specs <- lapply(names(region_defs), function(nm) {
  d    <- region_defs[[nm]]
  geom <- make_region_geom(d$biol_regio)
  list(
    name   = nm,
    geom   = geom,
    suffix = d$suffix,
    hex    = make_hex_grid(study_area = geom, n_hexagons = cfg$n_hexagons),
    # Atlas-region outlines clipped to this region (drawn on honeycomb panels;
    # matches the clipping assess_region does internally for modelled species).
    bounds = suppressWarnings(sf::st_intersection(atlas_regions, geom))
  )
})
names(region_specs) <- names(region_defs)

# ============================================================
# Per-species products
#
# Iterate EVERY species that has a saved honeycomb record (data_used). Species
# with a fitted model AND a paired-survey change analysis get the full
# multi-page assessment PDF; all others get a honeycomb-only PDF.
# ============================================================

dat_used_files <- list.files(data_used_dir, pattern = "\\.rds$", full.names = TRUE)
stopifnot(length(dat_used_files) > 0)
message("Species honeycomb records found: ", length(dat_used_files))

for (i in seq_along(dat_used_files)) {

  dat_used <- readRDS(dat_used_files[i])

  # sp_file is taken from the filename so it always matches the names script 07
  # used for the prediction and raster files.
  sp_file    <- basename(dat_used_files[i]) |> stringr::str_remove("_1km\\.rds$")
  sp_english <- dat_used$sp_english

  pdf_path  <- file.path(fig_dir, paste0(sp_file, ".pdf"))
  pred_path <- file.path(pred_dir, paste0(sp_file, "_1km.rds"))

  # ----------------------------------------------------------
  # Decide what, if anything, needs to be generated
  # ----------------------------------------------------------
  
  # Desired behaviour:
  #   1. If the PDF already exists, skip immediately.
  #   2. If the species is modelable but predictions have not been generated,
  #      skip it rather than producing a honeycomb-only PDF.
  #   3. If the species is not modelable, generate a honeycomb-only PDF.
  #   4. If the species is modelable and predictions exist, generate the full
  #      package, provided the paired-survey summary needed for the comparison
  #      page is available.

  if (file.exists(pdf_path)) {
    message("Skipping ", sp_english, "; PDF already exists at: ", pdf_path)
    next
  }
  
  
  if(!"is_modelable" %in% names(dat_used)){
    if(file.exists(pred_path)){
      dat_used$is_modelable <- TRUE
    } else {
      dat_used$is_modelable <- FALSE
    }
   
  }
  
  is_modelable <- isTRUE(dat_used$is_modelable)
  has_model    <- file.exists(pred_path)
  paired       <- paired_summaries[[sp_english]]
  has_paired   <- !is.null(paired)

  if (is_modelable && !has_model) {
    message(
      "Skipping ", sp_english,
      "; species is modelable, but model predictions were not found."
    )
    next
  }

  if (is_modelable && has_model && !has_paired) {
    message(
      "Skipping ", sp_english,
      "; species is modelable and predictions exist, but paired-survey ",
      "summaries were not found. Run 07b_fit_models_to_shared_footprint.R first."
    )
    next
  }

  # Reconstruct this species' survey sf (geometry + attributes + count) by
  # rejoining the lightweight count table to the shared all_surveys table.
  # This is needed for both honeycomb-only PDFs and the full model package.
  sp_surveys <- load_species_surveys(dat_used, all_surveys)

  # ----------------------------------------------------------
  # Honeycomb-only branch for species that were not modelable
  # ----------------------------------------------------------

  if (!is_modelable) {
    message("Honeycomb-only maps for ", sp_english, " (species not modelable).")

    A2_obs <- sp_surveys %>%
      dplyr::filter(Survey_Type %in% c("Point_Count", "ARU"), Atlas == "OBBA2") %>%
      dplyr::mutate(count_per_effort = count)
    A3_obs <- sp_surveys %>%
      dplyr::filter(Survey_Type %in% c("Point_Count", "ARU"), Atlas == "OBBA3") %>%
      dplyr::mutate(count_per_effort = count)

    honey_pages <- lapply(region_specs, function(spec) {
      h <- build_period_honeycombs(
        region_geom   = spec$geom,
        region_hex    = spec$hex,
        region_bounds = spec$bounds,
        A2_dat        = A2_obs,
        A3_dat        = A3_obs,
        sp_english    = sp_english,
        title_suffix  = spec$suffix
      )

      page_title <- if (nzchar(spec$suffix)) {
        paste0(sp_english, " - ", spec$suffix)
      } else {
        sp_english
      }

      (h$A3 + margin_theme) + (h$A2 + margin_theme) +
        patchwork::plot_layout(ncol = 2) +
        patchwork::plot_annotation(
          title    = page_title,
          subtitle = "Observed survey effort and mean counts (no model fitted)",
          theme = ggplot2::theme(
            plot.title    = ggplot2::element_text(size = 18, face = "bold"),
            plot.subtitle = ggplot2::element_text(size = 12, colour = "grey30")
          )
        )
    })

    png_paths <- file.path(
      png_dir, paste0(sp_file, "_honey_page", seq_along(honey_pages), ".png")
    )
    for (k in seq_along(honey_pages)) {
      save_page(honey_pages[[k]], png_paths[k])
    }

    imgs <- magick::image_read(png_paths)
    magick::image_write(imgs, path = pdf_path, format = "pdf")
    next
  }

  # ----------------------------------------------------------
  # Full model products
  # ----------------------------------------------------------

  preds <- readRDS(pred_path)

  sp_code <- dat$species_to_model |>
    dplyr::filter(english_name == sp_english) |>
    dplyr::pull(species_id)

  if (length(sp_code) == 0) {
    warning("No species_id found for ", sp_english, "; using NA in raster metadata.")
    sp_code <- NA_character_
  }

  sp_model_summary <- model_summaries[[sp_english]]
  if (is.null(sp_model_summary)) {
    warning("No model summary found for ", sp_english, ".")
  }

  message("\nGenerating products for: ", sp_english)

  rast_path_a2  <- file.path(rast_dir, paste0(sp_file, "_a2.tif"))
  rast_path_a3  <- file.path(rast_dir, paste0(sp_file, "_a3.tif"))
  rast_path_chg <- file.path(rast_dir, paste0(sp_file, "_chg.tif"))

  # ----------------------------------------------------------
  # Raster products: Atlas 2, Atlas 3, absolute change
  # ----------------------------------------------------------

  a2 <- grid2 %>%
    dplyr::mutate(
      mu_q50      = preds$OBBA2_Corrected_for_Water$OBBA2_q50,
      CI_95_width = preds$OBBA2_Corrected_for_Water$OBBA2_upper -
        preds$OBBA2_Corrected_for_Water$OBBA2_lower
    )

  r2 <- rasterize_sf(
    grid_sf = a2, field = c("mu_q50", "CI_95_width"), res = cfg$plot_res,
    metadata = c(species_name = sp_english, species_id = sp_code,
                 species_filename = sp_file, model_name = model_name,
                 units = "Expected count (Atlas 2)")
  )
  terra::writeRaster(r2, filename = rast_path_a2, overwrite = TRUE)

  a3 <- grid3 %>%
    dplyr::mutate(
      mu_q50      = preds$OBBA3_Corrected_for_Water$OBBA3_q50,
      CI_95_width = preds$OBBA3_Corrected_for_Water$OBBA3_upper -
        preds$OBBA3_Corrected_for_Water$OBBA3_lower
    )

  r3 <- rasterize_sf(
    grid_sf = a3, field = c("mu_q50", "CI_95_width"), res = cfg$plot_res,
    metadata = c(species_name = sp_english, species_id = sp_code,
                 species_filename = sp_file, model_name = model_name,
                 units = "Expected count (Atlas 3)")
  )
  terra::writeRaster(r3, filename = rast_path_a3, overwrite = TRUE)

  chg_sf <- grid3 %>%
    dplyr::mutate(
      chg_q50     = preds$abs_change_Corrected_for_Water$abs_change_q50,
      CI_95_width = preds$abs_change$abs_change_upper -
        preds$abs_change$abs_change_lower
    )

  rchg <- rasterize_sf(
    grid_sf = chg_sf, field = c("chg_q50", "CI_95_width"), res = cfg$plot_res,
    metadata = c(species_name = sp_english, species_id = sp_code,
                 species_filename = sp_file, model_name = model_name,
                 units = "Change in expected counts (Atlas 2 to Atlas 3)")
  )
  terra::writeRaster(rchg, filename = rast_path_chg, overwrite = TRUE)

  # ----------------------------------------------------------
  # Relative-abundance rasters (shared absence floor + scale)
  # ----------------------------------------------------------

  rasters_relabund_prepared <- prepare_relative_abundance_rasters(
    Atlas2               = r2,
    Atlas3               = r3,
    absent_method        = "hybrid",
    rast_absent_limit    = cfg$relabund_absent_limit,
    absent_quantile      = 0.01,
    relative_to_quantile = 0.99,
    relative_fraction    = 0.01,
    rast_max_quantile    = 0.99
  )

  r2_clamped <- rasters_relabund_prepared$rasters$Atlas2
  r3_clamped <- rasters_relabund_prepared$rasters$Atlas3

  # ----------------------------------------------------------
  # Hex-level change map (Page 3, left)
  # ----------------------------------------------------------

  prov_change <- summarize_polygon_hex_draw_change(
    hex_draws = preds$hex_draws_Corrected_for_Water,
    hex_grid  = hex_grid,
    polygon   = study_boundary,
    ci_level  = cfg$ci_level
  ) |>
    dplyr::mutate(
      pct_change_median = 100 * prop_change_median,
      pct_change_qlow   = 100 * prop_change_qlow,
      pct_change_qhigh  = 100 * prop_change_qhigh
    )

  hex_change_sf <- summarize_hex_draw_change(
    hex_grid  = hex_grid,
    hex_draws = preds$hex_draws_Corrected_for_Water,
    ci_level  = cfg$ci_level
  ) |>
    classify_min_supported_change()

  Hex_Change_Map <- make_hex_abs_change_map(
    species_name      = sp_english,
    hex_change_sf     = hex_change_sf,
    region            = study_boundary,
    region_boundaries = atlas_regions,
    prov_change       = prov_change,
    ci_level          = cfg$ci_level,
    zlim              = rasters_relabund_prepared$zlim,
    water             = NULL,
    water_fill        = "gray97"
  )

  # ----------------------------------------------------------
  # Regional change estimates: full model vs paired surveys (Page 3)
  # ----------------------------------------------------------

  # ---- Full spatial model, per atlas region
  regional_estimates_FullModel <- data.frame()
  for (j in seq_len(nrow(atlas_regions))) {
    a_reg <- atlas_regions[j, ]

    reg_est <- summarize_polygon_hex_draw_change(
      hex_draws = preds$hex_draws_Corrected_for_Water,
      hex_grid  = hex_grid,
      polygon   = a_reg,
      ci_level  = cfg$ci_level
    ) |>
      dplyr::mutate(
        pct_change_median = 100 * prop_change_median,
        pct_change_qlow   = 100 * prop_change_qlow,
        pct_change_qhigh  = 100 * prop_change_qhigh
      ) %>%
      dplyr::mutate(Region_Number = a_reg$Biol_Regio,
                    Region_Name   = a_reg$ECOZONE_NA) %>%
      dplyr::relocate(Region_Name, Region_Number)

    regional_estimates_FullModel <- dplyr::bind_rows(regional_estimates_FullModel, reg_est)
  }

  # ---- Paired analysis (surveys within shared 50 m footprint)
  paired_change_summary <- paired_summaries[[sp_english]]$shared_change_summary %>%
    dplyr::rename(
      pct_change_median = pct_change_q50,
      pct_change_qlow   = pct_change_q05,
      pct_change_qhigh  = pct_change_q95
    )
  paired_data <- paired_summaries[[sp_english]]$shared_data

  # Hide change estimates if a species was detected in too few squares.
  data_availability <- sp_surveys %>%
    as.data.frame() %>%
    dplyr::filter(count > 0) %>%
    dplyr::group_by(Atlas, Biol_Region) %>%
    dplyr::summarise(n_sq_det = dplyr::n_distinct(square_id), .groups = "drop") %>%
    tidyr::pivot_wider(
      names_from = Atlas, values_from = n_sq_det,
      names_prefix = "n_sq_det_", values_fill = 0
    ) %>%
    dplyr::mutate(
      sufficient_data = n_sq_det_OBBA2 >= cfg$min_sq_det |
        n_sq_det_OBBA3 >= cfg$min_sq_det
    )

  change_estimate_cols <- c("pct_change_median", "pct_change_qlow", "pct_change_qhigh")

  regional_estimates_FullModel_masked <- regional_estimates_FullModel %>%
    dplyr::left_join(data_availability, by = c("Region_Number" = "Biol_Region")) %>%
    dplyr::mutate(sufficient_data = dplyr::coalesce(sufficient_data, FALSE)) %>%
    dplyr::mutate(
      dplyr::across(
        dplyr::all_of(change_estimate_cols),
        ~ dplyr::if_else(sufficient_data, .x, NA_real_)
      ),
      direction = dplyr::if_else(sufficient_data, direction, NA_character_)
    )

  paired_change_summary_masked <- paired_change_summary %>%
    dplyr::left_join(data_availability, by = c("Biol_Region" = "Biol_Region")) %>%
    dplyr::mutate(sufficient_data = dplyr::coalesce(sufficient_data, FALSE)) %>%
    dplyr::mutate(
      dplyr::across(
        dplyr::all_of(change_estimate_cols),
        ~ dplyr::if_else(sufficient_data, .x, NA_real_)
      )
    )

  change_comparison_plot <- make_change_comparison_plot(
    regional_estimates_FullModel = regional_estimates_FullModel_masked,
    paired_change_summary        = paired_change_summary_masked,
    title    = "Regional population change estimates",
    subtitle = "Comparison of full atlas model vs repeated surveys only"
  )

  paired_locations_map <-
    ggplot2::ggplot() +
    ggplot2::geom_sf(data = study_boundary, colour = "black") +
    ggplot2::geom_sf(data = paired_data, size = 0.1, col = "#1FAA59") +
    ggplot2::geom_sf(data = atlas_regions_clipped, fill = "transparent",
                     colour = "black", linewidth = 0.3) +
    ggplot2::ggtitle("Repeated survey locations") +
    ggplot2::theme_bw() +
    ggplot2::theme(
      axis.title = ggplot2::element_blank(),
      plot.title = ggplot2::element_text(size = 13),
      plot.margin = ggplot2::margin(5, 5, 5, 5)
    )

  paired_data_summary <- paired_data %>%
    as.data.frame() %>%
    dplyr::group_by(Biol_Region, Atlas) %>%
    dplyr::summarize(
      mean_count = mean(count),
      PObs       = mean(count > 0),
      n_surveys  = dplyr::n(),
      n_squares  = length(unique(square_id)),
      .groups    = "drop"
    ) %>%
    dplyr::left_join(
      as.data.frame(atlas_regions)[, c("Biol_Regio", "ECOZONE_NA")],
      by = c("Biol_Region" = "Biol_Regio")
    )

  paired_summary_table <- make_paired_summary_table(paired_data_summary)

  # ----------------------------------------------------------
  # Survey data prepared once, then assessed per region
  # ----------------------------------------------------------

  A2_dat_to_plot <- sp_surveys %>%
    dplyr::filter(Survey_Type %in% c("Point_Count", "ARU"), Atlas == "OBBA2") %>%
    dplyr::mutate(count_per_effort = count)

  A3_dat_to_plot <- sp_surveys %>%
    dplyr::filter(Survey_Type %in% c("Point_Count", "ARU"), Atlas == "OBBA3") %>%
    dplyr::mutate(count_per_effort = count)

  # One unified call per region (Provincial, Southern, Boreal, Hudson Bay).
  assessments <- lapply(region_specs, function(spec) {
    build_period_assessments(
      region_geom   = spec$geom,
      region_hex    = spec$hex,
      r2            = r2_clamped,
      r3            = r3_clamped,
      A2_dat        = A2_dat_to_plot,
      A3_dat        = A3_dat_to_plot,
      atlas_regions = atlas_regions,
      sp_english    = sp_english,
      title_suffix  = spec$suffix,
      colpal        = colpal_relabund
    )
  })
  names(assessments) <- names(region_specs)

  # ----------------------------------------------------------
  # Probability-of-observation maps (Page 10)
  # ----------------------------------------------------------

  pobs2 <- 1 - exp(-r2)
  pobs3 <- 1 - exp(-r3)

  rasters_pobs_prepared <- prepare_relative_abundance_rasters(
    Atlas2            = pobs2,
    Atlas3            = pobs3,
    rast_absent_limit = cfg$relabund_absent_limit,
    rast_max_quantile = 0.99
  )

  pobs_Map_Atlas2 <- make_map(
    species_name = sp_english, subtitle = "Probability of Observation - Atlas 2",
    legend_title = "P(Obs)\nper 5-min\npoint count",
    rast = rasters_pobs_prepared$rasters$Atlas2, region = study_boundary,
    water = NULL, colpal = colpal_pobs, water_fill = "white",
    transform = "identity", zlim = c(0, 1), zbreaks = seq(0, 1, length.out = 5)
  )

  pobs_Map_Atlas3 <- make_map(
    species_name = sp_english, subtitle = "Probability of Observation - Atlas 3",
    legend_title = "P(Obs)\nper 5-min\npoint count",
    rast = rasters_pobs_prepared$rasters$Atlas3, region = study_boundary,
    water = NULL, colpal = colpal_pobs, water_fill = "white",
    transform = "identity", zlim = c(0, 1), zbreaks = seq(0, 1, length.out = 5)
  )

  # ----------------------------------------------------------
  # Compose pages (same content, order, and layout as updated2)
  # ----------------------------------------------------------

  # Page 3 layout. Intermediate variables are kept (rather than collapsing into
  # one expression) so the patchwork operator precedence is identical to
  # updated2 and the composition is byte-for-byte the same.
  bottom_right_panel <-
    paired_locations_map |
    paired_summary_table +
    patchwork::plot_layout(widths = c(1, 1))

  right_panel <-
    change_comparison_plot /
    bottom_right_panel +
    patchwork::plot_layout(heights = c(0.5, 1))

  population_change_page <-
    Hex_Change_Map |
    right_panel +
    patchwork::plot_layout(widths = c(1.5, 1))

  pobs_page <-
    pobs_Map_Atlas3 + pobs_Map_Atlas2 +
    patchwork::plot_layout(ncol = 2, widths = c(1, 1))

  # Page plots in final PDF order. Parallel vectors (paths + plots) avoid the
  # invalid use of function calls as list() names.
  page_plots <- list(
    assessments$province$A3$plot_combined,   # page 1
    assessments$province$A2$plot_combined,   # page 2
    population_change_page,                  # page 3
    assessments$southern$A3$plot_combined,   # page 4
    assessments$southern$A2$plot_combined,   # page 5
    assessments$boreal$A3$plot_combined,     # page 6
    assessments$boreal$A2$plot_combined,     # page 7
    assessments$hb$A3$plot_combined,         # page 8
    assessments$hb$A2$plot_combined,         # page 9
    pobs_page                                # page 10
  )

  png_paths <- file.path(
    png_dir, paste0(sp_file, "_page", seq_along(page_plots), ".png")
  )

  for (k in seq_along(page_plots)) {
    save_page(page_plots[[k]], png_paths[k])
  }

  imgs <- magick::image_read(png_paths)
  magick::image_write(imgs, path = pdf_path, format = "pdf")
}

message("08_generate_model_products.R complete")
