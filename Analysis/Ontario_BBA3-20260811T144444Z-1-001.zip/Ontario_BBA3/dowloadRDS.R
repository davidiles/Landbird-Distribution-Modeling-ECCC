


library(googledrive)

drive_deauth()

folder <- as_id("1pRncZ1pdotNCUQbteuctRUoBsYgZC1VE")

files <- drive_ls(folder)


rds_files <- subset(files, grepl("\\.rds$", name))

for(i in seq_len(nrow(rds_files))) {
  
  cat("Downloading:", rds_files$name[i], "\n")
  
  drive_download(
    file = rds_files[i, ],
    path = file.path("E:/PredictionsDownload", rds_files$name[i]),
    overwrite = TRUE
  )
  
  cat(rds_files$name[i]," Downloaded ", 120-i , " to go." , "\n")
}

?drive_download
i<-1
